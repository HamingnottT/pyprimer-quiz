# initializes program

import questions

def main():
    questions.main()

if __name__ == '__main__':
    main()