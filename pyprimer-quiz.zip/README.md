# pyprimer-quiz
Python practice
